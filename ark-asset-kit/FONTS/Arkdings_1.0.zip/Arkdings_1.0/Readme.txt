Hi, welcome to Arkdings!

This is a font that can be installed on your computer and used to place the Ark logo in all of your computer programs whenever you need it.

This font is brought to you by ArkStickers at ArkStickers.com, and the Ark Community Fund, at www.ArkCommunity.Fund

This is Arkdings Version 1.0, which has glyphs for the characters of 0,1,2,3,4,5,6,7,8,9

Install the font, and type the characters to see all the logos.

Here are some official colors for your reference:

2018 Electric Red - #f1373a
2017 Classic  Red - #cc0101
Alt Projects Blue - #2897c4

If you like using this font, please show your appreciation by buying some Ark Stickers.

Cheers, and enjoy!

ArkStickers.com